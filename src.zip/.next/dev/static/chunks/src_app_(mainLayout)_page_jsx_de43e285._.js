(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/src_87a0a5fe._.js",
  "static/chunks/node_modules_next_a62874fb._.js",
  "static/chunks/node_modules_motion-dom_dist_es_da948acf._.js",
  "static/chunks/node_modules_framer-motion_dist_es_b71551f1._.js",
  "static/chunks/node_modules_react-icons_fa_index_mjs_0459ff00._.js",
  "static/chunks/node_modules_react-icons_pi_index_mjs_39252f67._.js",
  "static/chunks/node_modules_react-icons_hi2_index_mjs_94c5f7f2._.js",
  "static/chunks/node_modules_react-icons_fc_index_mjs_c0b04ec4._.js",
  "static/chunks/node_modules_motion-utils_dist_es_870698ef._.js"
],
    source: "dynamic"
});

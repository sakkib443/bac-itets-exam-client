(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/src_components_coursepage_RightCoursesDetalis_jsx_8ab757a6._.js",
  "static/chunks/_9dff23da._.js"
],
    source: "dynamic"
});

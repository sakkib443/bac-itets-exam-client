(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/src_0c284171._.js",
  "static/chunks/node_modules_react-icons_fa_index_mjs_0459ff00._.js",
  "static/chunks/node_modules_react-icons_md_index_mjs_65e576c2._.js",
  "static/chunks/node_modules_react-icons_ri_index_mjs_150b4c77._.js",
  "static/chunks/node_modules_react-icons_tfi_index_mjs_afaa25af._.js",
  "static/chunks/node_modules_react-icons_bs_index_mjs_8a44a60a._.js",
  "static/chunks/node_modules_next_a62874fb._.js"
],
    source: "dynamic"
});

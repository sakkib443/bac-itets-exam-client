(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/node_modules_next_a62874fb._.js",
  "static/chunks/node_modules_react-icons_md_index_mjs_65e576c2._.js",
  "static/chunks/node_modules_react-icons_ri_index_mjs_150b4c77._.js",
  "static/chunks/node_modules_react-icons_fa_index_mjs_0459ff00._.js",
  "static/chunks/src_60ba7210._.js"
],
    source: "dynamic"
});

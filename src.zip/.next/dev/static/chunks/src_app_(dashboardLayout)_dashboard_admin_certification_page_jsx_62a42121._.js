(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/src_app_(dashboardLayout)_dashboard_admin_certification_page_jsx_c205b263._.js"
],
    source: "dynamic"
});

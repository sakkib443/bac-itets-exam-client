(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/src_app_(dashboardLayout)_dashboard_admin_category_page_jsx_cfbb2351._.js"
],
    source: "dynamic"
});

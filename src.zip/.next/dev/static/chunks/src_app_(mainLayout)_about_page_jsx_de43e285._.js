(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/node_modules_next_dist_60d9f176._.js",
  "static/chunks/node_modules_react-icons_fa_index_mjs_0459ff00._.js",
  "static/chunks/node_modules_react-icons_hi_index_mjs_c1b692d7._.js",
  "static/chunks/node_modules_motion-dom_dist_es_da948acf._.js",
  "static/chunks/node_modules_framer-motion_dist_es_b71551f1._.js",
  "static/chunks/node_modules_motion-utils_dist_es_870698ef._.js",
  "static/chunks/src_components_Aboutpage_Count_jsx_b8752ccf._.js"
],
    source: "dynamic"
});

(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/[root-of-the-server]__523bc366._.css",
  "static/chunks/node_modules_react-icons_bi_index_mjs_80d32eb5._.js",
  "static/chunks/node_modules_react-icons_lu_index_mjs_9c1f52d1._.js",
  "static/chunks/node_modules_react-icons_io_index_mjs_7f31b177._.js",
  "static/chunks/node_modules_react-icons_io5_index_mjs_9bce8f6c._.js",
  "static/chunks/node_modules_react-icons_sl_index_mjs_cb4be900._.js",
  "static/chunks/node_modules_react-icons_fi_index_mjs_0a78009b._.js",
  "static/chunks/node_modules_react-icons_lib_844c6c50._.js",
  "static/chunks/node_modules_bca6f603._.js",
  "static/chunks/src_8a781207._.js"
],
    source: "dynamic"
});

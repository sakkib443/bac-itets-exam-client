(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/src_app_(dashboardLayout)_dashboard_admin_feedback_page_jsx_8dc3f95e._.js"
],
    source: "dynamic"
});

(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/src_app_(mainLayout)_mentors_[id]_page_jsx_c724ca2c._.js"
],
    source: "dynamic"
});

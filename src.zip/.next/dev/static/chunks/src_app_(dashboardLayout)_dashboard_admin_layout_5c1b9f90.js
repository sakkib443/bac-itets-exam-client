(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/node_modules_react-icons_fi_index_mjs_0a78009b._.js",
  "static/chunks/src_components_Admin_AdminSidebar_jsx_11e0cf59._.js"
],
    source: "dynamic"
});

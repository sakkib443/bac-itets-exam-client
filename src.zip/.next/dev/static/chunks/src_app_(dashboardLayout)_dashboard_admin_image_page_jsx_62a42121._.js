(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/src_app_(dashboardLayout)_dashboard_admin_image_page_jsx_4b4783a1._.js"
],
    source: "dynamic"
});

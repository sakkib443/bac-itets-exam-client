module.exports = [
"[project]/.next-internal/server/app/(mainLayout)/phoenix/page/actions.js [app-rsc] (server actions loader, ecmascript)", ((__turbopack_context__, module, exports) => {

}),
];

//# sourceMappingURL=_next-internal_server_app_%28mainLayout%29_phoenix_page_actions_135167e8.js.map
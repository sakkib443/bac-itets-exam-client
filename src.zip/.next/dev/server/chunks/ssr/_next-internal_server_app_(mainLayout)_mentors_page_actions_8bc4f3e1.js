module.exports = [
"[project]/.next-internal/server/app/(mainLayout)/mentors/page/actions.js [app-rsc] (server actions loader, ecmascript)", ((__turbopack_context__, module, exports) => {

}),
];

//# sourceMappingURL=_next-internal_server_app_%28mainLayout%29_mentors_page_actions_8bc4f3e1.js.map
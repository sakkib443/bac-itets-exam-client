module.exports = [
"[project]/src/app/(dashboardLayout)/dashboard/admin/page.js [app-ssr] (ecmascript)", ((__turbopack_context__, module, exports) => {

const e = new Error("Could not parse module '[project]/src/app/(dashboardLayout)/dashboard/admin/page.js'\n\nParenthesized expression cannot be empty");
e.code = 'MODULE_UNPARSABLE';
throw e;
}),
];
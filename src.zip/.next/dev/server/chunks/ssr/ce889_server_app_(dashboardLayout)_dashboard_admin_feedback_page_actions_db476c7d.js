module.exports = [
"[project]/.next-internal/server/app/(dashboardLayout)/dashboard/admin/feedback/page/actions.js [app-rsc] (server actions loader, ecmascript)", ((__turbopack_context__, module, exports) => {

}),
];

//# sourceMappingURL=ce889_server_app_%28dashboardLayout%29_dashboard_admin_feedback_page_actions_db476c7d.js.map
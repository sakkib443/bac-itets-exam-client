module.exports = [
"[project]/.next-internal/server/app/(mainLayout)/events/page/actions.js [app-rsc] (server actions loader, ecmascript)", ((__turbopack_context__, module, exports) => {

}),
];

//# sourceMappingURL=_next-internal_server_app_%28mainLayout%29_events_page_actions_0918b6cf.js.map
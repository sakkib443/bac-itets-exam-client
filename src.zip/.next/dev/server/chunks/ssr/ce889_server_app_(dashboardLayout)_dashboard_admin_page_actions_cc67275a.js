module.exports = [
"[project]/.next-internal/server/app/(dashboardLayout)/dashboard/admin/page/actions.js [app-rsc] (server actions loader, ecmascript)", ((__turbopack_context__, module, exports) => {

}),
];

//# sourceMappingURL=ce889_server_app_%28dashboardLayout%29_dashboard_admin_page_actions_cc67275a.js.map
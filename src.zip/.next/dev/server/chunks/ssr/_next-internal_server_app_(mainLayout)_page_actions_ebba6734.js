module.exports = [
"[project]/.next-internal/server/app/(mainLayout)/page/actions.js [app-rsc] (server actions loader, ecmascript)", ((__turbopack_context__, module, exports) => {

}),
];

//# sourceMappingURL=_next-internal_server_app_%28mainLayout%29_page_actions_ebba6734.js.map
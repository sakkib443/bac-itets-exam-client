module.exports = [
"[project]/.next-internal/server/app/(mainLayout)/certification/page/actions.js [app-rsc] (server actions loader, ecmascript)", ((__turbopack_context__, module, exports) => {

}),
];

//# sourceMappingURL=_next-internal_server_app_%28mainLayout%29_certification_page_actions_306eeb4d.js.map
module.exports = [
"[project]/.next-internal/server/app/(mainLayout)/courses/[courseid]/page/actions.js [app-rsc] (server actions loader, ecmascript)", ((__turbopack_context__, module, exports) => {

}),
];

//# sourceMappingURL=_next-internal_server_app_%28mainLayout%29_courses_%5Bcourseid%5D_page_actions_38894c21.js.map
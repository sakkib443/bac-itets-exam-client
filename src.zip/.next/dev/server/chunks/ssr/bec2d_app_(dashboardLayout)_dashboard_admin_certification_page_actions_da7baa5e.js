module.exports = [
"[project]/.next-internal/server/app/(dashboardLayout)/dashboard/admin/certification/page/actions.js [app-rsc] (server actions loader, ecmascript)", ((__turbopack_context__, module, exports) => {

}),
];

//# sourceMappingURL=bec2d_app_%28dashboardLayout%29_dashboard_admin_certification_page_actions_da7baa5e.js.map
'use client';

import ProtectedRoute from '@/app/providers/protectedRoutes';
import React from 'react';
import { FiUsers, FiBook, FiAward, FiMessageSquare } from 'react-icons/fi';

export default function AdminDashboard() {
  const stats = [
    {
      title: 'Total Users',
      count: '1,234',
      icon: FiUsers,
      color: 'from-blue-500 to-blue-600',
      bgColor: 'bg-blue-50',
    },
    {
      title: 'Total Courses',
      count: '48',
      icon: FiBook,
      color: 'from-orange-500 to-orange-600',
      bgColor: 'bg-orange-50',
    },
    {
      title: 'Certifications',
      count: '156',
      icon: FiAward,
      color: 'from-teal-500 to-teal-600',
      bgColor: 'bg-teal-50',
    },
    {
      title: 'Feedback',
      count: '89',
      icon: FiMessageSquare,
      color: 'from-purple-500 to-purple-600',
      bgColor: 'bg-purple-50',
    },
  ];

  return (
    <ProtectedRoute role="admin">
      <div className="p-6 lg:p-8 space-y-8">
      {/* Header */}
      <div>
        <h1 className="text-3xl font-bold text-slate-900">Dashboard</h1>
        <p className="text-slate-500 mt-2">Welcome back! Here's an overview of your academy</p>
      </div>

      {/* Stats Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        {stats.map((stat) => {
          const Icon = stat.icon;
          return (
            <div key={stat.title} className="bg-white rounded-xl border border-slate-200 p-6 shadow-sm hover:shadow-md transition-shadow">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-slate-600 text-sm font-medium">{stat.title}</p>
                  <p className="text-3xl font-bold text-slate-900 mt-2">{stat.count}</p>
                </div>
                <div className={`${stat.bgColor} p-4 rounded-lg`}>
                  <Icon className={`bg-gradient-to-r ${stat.color} bg-clip-text text-transparent text-2xl`} />
                </div>
              </div>
            </div>
          );
        })}
      </div>

      {/* Content Sections */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Recent Activities */}
        <div className="lg:col-span-2 bg-white rounded-xl border border-slate-200 p-6">
          <h2 className="text-xl font-bold text-slate-900 mb-4">Recent Activities</h2>
          <div className="space-y-4">
            {[1, 2, 3, 4].map((item) => (
              <div key={item} className="flex items-center gap-3 pb-4 border-b border-slate-200 last:border-b-0">
                <div className="w-10 h-10 rounded-full bg-gradient-to-r from-orange-500 to-teal-500"></div>
                <div className="flex-1">
                  <p className="text-sm font-medium text-slate-900">User activity item {item}</p>
                  <p className="text-xs text-slate-500">2 hours ago</p>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Quick Links */}
        <div className="bg-white rounded-xl border border-slate-200 p-6">
          <h2 className="text-xl font-bold text-slate-900 mb-4">Quick Actions</h2>
          <div className="space-y-2">
            <button className="w-full px-4 py-3 rounded-lg btn-gradient text-white font-medium hover:shadow-lg transition-shadow">
              Create Course
            </button>
            <button className="w-full px-4 py-3 rounded-lg border border-slate-300 text-slate-700 font-medium hover:bg-slate-50 transition-colors">
              Add Mentor
            </button>
            <button className="w-full px-4 py-3 rounded-lg border border-slate-300 text-slate-700 font-medium hover:bg-slate-50 transition-colors">
              View Reports
            </button>
          </div>
        </div>
      </div>
    </div>
    </ProtectedRoute>
  );
}

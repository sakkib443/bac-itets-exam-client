import React from 'react'

const PhoenixPage = () => {
  return (
    <div> 
        <div className="flex items-center justify-center">
        <h1 className="text-2xl font-bold my-20">Phoenix Page Coming Soon...</h1>
        </div>
    </div>
  )
}

export default PhoenixPage